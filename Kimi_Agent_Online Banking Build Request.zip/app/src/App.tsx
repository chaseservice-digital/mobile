import { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { 
  Lock, Unlock, Search, LogOut, User, CreditCard, 
  DollarSign, Activity, Shield, Eye, EyeOff,
  ArrowRight, Building2, Users, AlertTriangle, Home,
  ChevronRight, Bell, Landmark, Wallet, TrendingUp,
  CheckCircle, RefreshCw, Download, Send, Plus, Minus,
  Settings, Smartphone, FileText, QrCode, MapPin, Calendar,
  Phone, Mail, X, Check, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import './App.css';

// Types
interface User {
  id: string;
  name: string;
  email: string;
  accountNumber: string;
  balance: number;
  isLocked: boolean;
  role: 'customer' | 'admin';
  dob: string;
  location: string;
  phone: string;
}

interface PendingTransfer {
  id: string;
  fromAccount: string;
  toBank: string;
  toAccount: string;
  accountHolder: string;
  amount: number;
  memo: string;
  pin: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
}

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'completed' | 'pending' | 'failed';
}

interface BankAccount {
  id: string;
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  accountType: string;
  balance: number;
  routingNumber: string;
}

// Mock Data
const MOCK_TRANSACTIONS: Transaction[] = [
  { id: '1', date: '2024-03-08', description: 'Wire Transfer - Investment Corp', amount: 50000, type: 'credit', status: 'completed' },
  { id: '2', date: '2024-03-07', description: 'Real Estate Purchase - Property LLC', amount: 350000, type: 'debit', status: 'completed' },
  { id: '3', date: '2024-03-06', description: 'Stock Dividend - Tech Holdings', amount: 12500, type: 'credit', status: 'completed' },
  { id: '4', date: '2024-03-05', description: 'Luxury Vehicle Purchase', amount: 85000, type: 'debit', status: 'completed' },
  { id: '5', date: '2024-03-04', description: 'Consulting Fee - Global Solutions', amount: 25000, type: 'credit', status: 'completed' },
  { id: '6', date: '2024-03-03', description: 'Private Jet Charter', amount: 18000, type: 'debit', status: 'completed' },
  { id: '7', date: '2024-03-02', description: 'Investment Return - Venture Fund', amount: 75000, type: 'credit', status: 'completed' },
  { id: '8', date: '2024-03-01', description: 'Yacht Maintenance', amount: 22000, type: 'debit', status: 'completed' },
];

const USA_BANKS = [
  'JPMorgan Chase', 'Bank of America', 'Wells Fargo', 'Citibank', 'Goldman Sachs',
  'Morgan Stanley', 'U.S. Bank', 'PNC Bank', 'Truist', 'Capital One',
  'TD Bank', 'Charles Schwab', 'State Street', 'BNY Mellon', 'HSBC USA',
  'Fifth Third Bank', 'Citizens Bank', 'KeyBank', 'Ally Bank', 'Discover Bank'
];

const MOCK_BANK_ACCOUNTS: BankAccount[] = [
  { id: '1', bankName: 'Bank of America', accountHolder: 'John Smith', accountNumber: '****7821', accountType: 'Checking', balance: 45680, routingNumber: '021000322' },
  { id: '2', bankName: 'Wells Fargo', accountHolder: 'Sarah Johnson', accountNumber: '****9345', accountType: 'Savings', balance: 127500, routingNumber: '121042882' },
  { id: '3', bankName: 'Citibank', accountHolder: 'Michael Chen', accountNumber: '****2156', accountType: 'Business', balance: 342000, routingNumber: '021000089' },
  { id: '4', bankName: 'Goldman Sachs', accountHolder: 'Emma Davis', accountNumber: '****6734', accountType: 'Investment', balance: 890000, routingNumber: '026013576' },
  { id: '5', bankName: 'U.S. Bank', accountHolder: 'Robert Wilson', accountNumber: '****4521', accountType: 'Checking', balance: 23400, routingNumber: '122105155' },
  { id: '6', bankName: 'PNC Bank', accountHolder: 'Lisa Anderson', accountNumber: '****8934', accountType: 'Savings', balance: 67800, routingNumber: '043000096' },
  { id: '7', bankName: 'Capital One', accountHolder: 'David Brown', accountNumber: '****1278', accountType: 'Credit Card', balance: -12500, routingNumber: '056073502' },
  { id: '8', bankName: 'TD Bank', accountHolder: 'Jennifer Lee', accountNumber: '****3456', accountType: 'Checking', balance: 8920, routingNumber: '031101266' },
];

// Global user state (shared between components)
let globalUserState: User = {
  id: '1',
  name: 'Patrick Lormard',
  email: 'patrick.lormard@email.com',
  accountNumber: '****4532',
  balance: 1200000,
  isLocked: false,
  role: 'customer',
  dob: '22 Aug 1961',
  location: 'Savannah, Georgia',
  phone: '+1 (912) 555-0147'
};

// Pending transfers storage
let pendingTransfers: PendingTransfer[] = [];

// News/Notifications
const NEWS_ITEMS = [
  { id: '1', title: 'Welcome to Chase Online Banking', message: 'Thank you for banking with us. Your account is now fully activated.', date: '2024-03-09', type: 'info', read: false },
  { id: '2', title: 'New Security Features', message: 'We have enhanced our security protocols to keep your account safe.', date: '2024-03-08', type: 'security', read: false },
  { id: '3', title: 'Mobile App Update', message: 'Download our new mobile app for easier banking on the go.', date: '2024-03-07', type: 'update', read: true },
  { id: '4', title: 'Transfer Limit Increased', message: 'Your daily transfer limit has been increased to $500,000.', date: '2024-03-06', type: 'info', read: true },
  { id: '5', title: 'Scheduled Maintenance', message: 'System maintenance scheduled for March 15, 2024 at 2:00 AM EST.', date: '2024-03-05', type: 'alert', read: false },
];

// Customer Care Contact Info
const CUSTOMER_CARE = {
  phone: '+1 (555) 123-4567',
  email: 'agent.chaseservice@gmail.com'
};

// Auth Context with localStorage persistence
const useAuth = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('chase_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('chase_authenticated') === 'true';
  });
  const [isAdmin, setIsAdmin] = useState(() => {
    return localStorage.getItem('chase_is_admin') === 'true';
  });

  const login = (email: string, password: string): boolean => {
    // Accept ANY email and password for the main account
    if (email.trim() && password.trim()) {
      // Check if account is locked
      if (globalUserState.isLocked) {
        return false;
      }
      // Update email to whatever user entered
      const loggedInUser = { ...globalUserState, email: email.trim() };
      globalUserState = loggedInUser;
      setUser(loggedInUser);
      setIsAuthenticated(true);
      setIsAdmin(false);
      // Persist to localStorage
      localStorage.setItem('chase_user', JSON.stringify(loggedInUser));
      localStorage.setItem('chase_authenticated', 'true');
      localStorage.setItem('chase_is_admin', 'false');
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    // Clear localStorage
    localStorage.removeItem('chase_user');
    localStorage.removeItem('chase_authenticated');
    localStorage.removeItem('chase_is_admin');
  };

  const adminLogin = (username: string, password: string): boolean => {
    if (username === 'admin' && password === 'admin123') {
      const adminUser = { ...globalUserState, role: 'admin' as const };
      setUser(adminUser);
      setIsAuthenticated(true);
      setIsAdmin(true);
      // Persist to localStorage
      localStorage.setItem('chase_user', JSON.stringify(adminUser));
      localStorage.setItem('chase_authenticated', 'true');
      localStorage.setItem('chase_is_admin', 'true');
      return true;
    }
    return false;
  };

  const updateUserLockStatus = (userId: string, isLocked: boolean) => {
    if (globalUserState.id === userId) {
      globalUserState = { ...globalUserState, isLocked };
    }
  };

  const getCurrentUserState = () => globalUserState;

  return { user, isAuthenticated, isAdmin, login, logout, adminLogin, updateUserLockStatus, getCurrentUserState };
};

// Login Page Component
const LoginPage = ({ onLogin }: { onLogin: (email: string, password: string) => boolean }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showCrash, setShowCrash] = useState(false);
  const [showForgotCrash, setShowForgotCrash] = useState(false);
  const [isEnroll, setIsEnroll] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isEnroll) {
      setShowCrash(true);
      return;
    }
    
    const success = onLogin(email, password);
    if (success) {
      navigate('/dashboard');
    } else {
      setError(`Account is locked. Please contact customer care at ${CUSTOMER_CARE.email}.`);
    }
  };

  const handleForgotPassword = () => {
    setShowForgotCrash(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0C4BB9] via-[#003087] to-[#002970] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-2xl shadow-2xl mb-4">
            <Building2 className="w-12 h-12 text-[#0C4BB9]" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Chase Bank</h1>
          <p className="text-blue-200">Online Banking</p>
        </div>

        <Card className="border-0 shadow-2xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-[#0C4BB9] via-[#003087] to-[#0C4BB9]"></div>
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl font-semibold text-center">
              {isEnroll ? 'Enroll in Online Banking' : 'Sign In'}
            </CardTitle>
            <CardDescription className="text-center">
              {isEnroll ? 'Create your online banking account' : 'Access your Chase Bank account'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4 bg-red-50 border-red-200">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-700 text-sm">{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  {isEnroll ? 'Email Address' : 'Username / Email'}
                </label>
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Password</label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-12 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {!isEnroll && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input type="checkbox" className="rounded border-gray-300" />
                    <span className="text-gray-600">Remember me</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-[#0C4BB9] hover:text-[#003087] font-medium"
                  >
                    Forgot password?
                  </button>
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 bg-[#0C4BB9] hover:bg-[#003087] text-white font-semibold text-lg"
              >
                {isEnroll ? 'Continue Enrollment' : 'Sign In'}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => setIsEnroll(!isEnroll)}
                className="text-[#0C4BB9] hover:text-[#003087] font-medium text-sm"
              >
                {isEnroll ? 'Already enrolled? Sign in' : "Not enrolled? Sign up now."}
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-200">
              <button
                onClick={() => navigate('/admin-login')}
                className="w-full py-2 text-sm text-gray-500 hover:text-gray-700 flex items-center justify-center gap-2"
              >
                <Shield className="w-4 h-4" />
                Customer Care Admin Access
              </button>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-blue-200 text-sm mt-6">
          © 2024 Chase Bank. All rights reserved.
        </p>
      </div>

      {/* Crash Dialog for Enrollment */}
      <Dialog open={showCrash} onOpenChange={setShowCrash}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-6 h-6" />
              System Error
            </DialogTitle>
            <DialogDescription className="text-base">
              <div className="mt-4 space-y-4">
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 font-mono text-sm text-red-800">
                  <p className="font-bold">Error Code: 0x80070057</p>
                  <p className="mt-2">Exception in thread "main" java.lang.NullPointerException</p>
                  <p className="mt-1">at com.chase.enrollment.RegistrationServlet.processRequest(RegistrationServlet.java:142)</p>
                  <p>at com.chase.enrollment.RegistrationServlet.doPost(RegistrationServlet.java:89)</p>
                  <p>at javax.servlet.http.HttpServlet.service(HttpServlet.java:681)</p>
                  <p className="mt-2 text-xs text-red-600">Database connection timeout. Enrollment service unavailable.</p>
                </div>
                <p className="text-gray-600">
                  We apologize for the inconvenience. Our enrollment system is currently experiencing technical difficulties. 
                  Please try again later or visit a Chase branch near you.
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={() => setShowCrash(false)} variant="outline">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Crash Dialog for Forgot Password */}
      <Dialog open={showForgotCrash} onOpenChange={setShowForgotCrash}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-6 h-6" />
              Service Unavailable
            </DialogTitle>
            <DialogDescription className="text-base">
              <div className="mt-4 space-y-4">
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 font-mono text-sm text-red-800">
                  <p className="font-bold">Error Code: 0x80131500</p>
                  <p className="mt-2">System.IO.IOException: The password reset service is not responding.</p>
                  <p className="mt-1">at Chase.Identity.PasswordResetService.GenerateToken(PasswordResetService.cs:256)</p>
                  <p>at Chase.Identity.PasswordResetService.InitiateReset(PasswordResetService.cs:178)</p>
                  <p className="mt-2 text-xs text-red-600">SMTP server connection failed. Email service down.</p>
                </div>
                <p className="text-gray-600">
                  The password reset feature is temporarily unavailable due to system maintenance. 
                  Please contact customer service at {CUSTOMER_CARE.email} for assistance.
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={() => setShowForgotCrash(false)} variant="outline">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Admin Login Page
const AdminLoginPage = ({ onAdminLogin }: { onAdminLogin: (u: string, p: string) => boolean }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const success = onAdminLogin(username, password);
    if (success) {
      navigate('/admin');
    } else {
      setError('Invalid admin credentials.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-2xl shadow-2xl mb-4">
            <Shield className="w-12 h-12 text-gray-800" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Customer Care</h1>
          <p className="text-gray-400">Admin Panel</p>
        </div>

        <Card className="border-0 shadow-2xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-semibold text-center">Admin Sign In</CardTitle>
            <CardDescription className="text-center">
              Access the customer care management system
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4 bg-red-50 border-red-200">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-700 text-sm">{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Username</label>
                <Input
                  type="text"
                  placeholder="Enter admin username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="h-12"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Password</label>
                <Input
                  type="password"
                  placeholder="Enter admin password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full h-12 bg-gray-800 hover:bg-gray-900 text-white font-semibold text-lg"
              >
                <Shield className="w-5 h-5 mr-2" />
                Access Admin Panel
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/')}
                className="text-gray-500 hover:text-gray-700 font-medium text-sm"
              >
                Back to Customer Login
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Dashboard Component
const Dashboard = ({ onLogout }: { onLogout: () => void }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showBalance, setShowBalance] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<BankAccount[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<BankAccount | null>(null);
  
  // Settings dialog
  const [showSettings, setShowSettings] = useState(false);
  
  // Transfer state
  const [transferBank, setTransferBank] = useState('');
  const [transferAccount, setTransferAccount] = useState('');
  const [transferHolder, setTransferHolder] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferMemo, setTransferMemo] = useState('');
  const [transferPin, setTransferPin] = useState('');
  const [showPinDialog, setShowPinDialog] = useState(false);
  const [showPendingDialog, setShowPendingDialog] = useState(false);
  const [showContactAgentDialog, setShowContactAgentDialog] = useState(false);
  
  // Feature dialogs
  const [showTopup, setShowTopup] = useState(false);
  const [showMobileDeposit, setShowMobileDeposit] = useState(false);
  const [showCheckDeposit, setShowCheckDeposit] = useState(false);
  const [showGetCard, setShowGetCard] = useState(false);
  
  // Notifications
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Settings - Change password/email
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showChangeEmail, setShowChangeEmail] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [emailPassword, setEmailPassword] = useState('');
  
  // Use global user state to always get current lock status
  const user = globalUserState;

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setTimeout(() => {
      const results = MOCK_BANK_ACCOUNTS.filter(acc => 
        acc.bankName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        acc.accountHolder.toLowerCase().includes(searchQuery.toLowerCase()) ||
        acc.accountNumber.includes(searchQuery)
      );
      setSearchResults(results);
      setIsSearching(false);
    }, 1000);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const totalBalance = user.balance;
  const availableBalance = user.balance * 0.95;
  
  const handleTransferSubmit = () => {
    if (!transferBank || !transferAccount || !transferAmount) return;
    setShowPinDialog(true);
  };
  
  const handlePinSubmit = () => {
    if (transferPin.length !== 4) return;
    
    // Show contact agent dialog instead of auto-pending
    setShowPinDialog(false);
    setShowContactAgentDialog(true);
    
    // Reset form
    setTransferBank('');
    setTransferAccount('');
    setTransferHolder('');
    setTransferAmount('');
    setTransferMemo('');
    setTransferPin('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#0C4BB9] rounded-lg flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Chase Bank</h1>
                <p className="text-xs text-gray-500">Online Banking</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button 
                onClick={() => setShowSettings(true)}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
              
              {/* Notifications Dropdown */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-200">
                      <h3 className="font-semibold text-gray-900">Notifications</h3>
                    </div>
                    <div className="max-h-80 overflow-y-auto">
                      {NEWS_ITEMS.map((news) => (
                        <div key={news.id} className={`p-4 border-b border-gray-100 hover:bg-gray-50 ${!news.read ? 'bg-blue-50' : ''}`}>
                          <div className="flex items-start gap-3">
                            <div className={`w-2 h-2 rounded-full mt-2 ${
                              news.type === 'security' ? 'bg-red-500' : 
                              news.type === 'alert' ? 'bg-amber-500' : 
                              news.type === 'update' ? 'bg-purple-500' : 'bg-blue-500'
                            }`} />
                            <div className="flex-1">
                              <p className="font-medium text-sm text-gray-900">{news.title}</p>
                              <p className="text-xs text-gray-500 mt-1">{news.message}</p>
                              <p className="text-xs text-gray-400 mt-1">{news.date}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              {/* Profile - Clickable to Settings */}
              <button 
                onClick={() => setShowSettings(true)}
                className="flex items-center gap-3 hover:bg-gray-100 rounded-lg p-1 pr-3 transition-colors"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-gray-900">{user.name}</p>
                  <p className="text-xs text-gray-500">Personal Account</p>
                </div>
                <div className="w-10 h-10 bg-[#0C4BB9] rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
              </button>
              
              <Button variant="ghost" size="sm" onClick={onLogout} className="text-gray-500">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white border border-gray-200 p-1">
            <TabsTrigger value="overview" className="data-[state=active]:bg-[#0C4BB9] data-[state=active]:text-white">
              <Home className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="accounts" className="data-[state=active]:bg-[#0C4BB9] data-[state=active]:text-white">
              <CreditCard className="w-4 h-4 mr-2" />
              Accounts
            </TabsTrigger>
            <TabsTrigger value="transfers" className="data-[state=active]:bg-[#0C4BB9] data-[state=active]:text-white">
              <Send className="w-4 h-4 mr-2" />
              Transfers
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-[#0C4BB9] data-[state=active]:text-white">
              <Search className="w-4 h-4 mr-2" />
              Bank Search
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Welcome Banner */}
            <div className="bg-gradient-to-r from-[#0C4BB9] to-[#003087] rounded-2xl p-8 text-white">
              <h2 className="text-3xl font-bold mb-2">Welcome back, {user.name.split(' ')[0]}!</h2>
              <p className="text-blue-100">Here's your financial overview for today.</p>
            </div>

            {/* Balance Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-0 shadow-lg bg-gradient-to-br from-[#0C4BB9] to-[#003087] text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-white/20 rounded-lg">
                      <Wallet className="w-6 h-6" />
                    </div>
                    <button 
                      onClick={() => setShowBalance(!showBalance)}
                      className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                    >
                      {showBalance ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  <p className="text-blue-100 text-sm mb-1">Total Balance</p>
                  <p className="text-3xl font-bold">
                    {showBalance ? formatCurrency(totalBalance) : '****'}
                  </p>
                  <p className="text-blue-200 text-xs mt-2">Account {user.accountNumber}</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-green-100 rounded-lg">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                    <Badge className="bg-green-100 text-green-700">+12.5%</Badge>
                  </div>
                  <p className="text-gray-500 text-sm mb-1">Available Balance</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {showBalance ? formatCurrency(availableBalance) : '****'}
                  </p>
                  <p className="text-gray-400 text-xs mt-2">Updated just now</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-purple-100 rounded-lg">
                      <Activity className="w-6 h-6 text-purple-600" />
                    </div>
                  </div>
                  <p className="text-gray-500 text-sm mb-1">Monthly Activity</p>
                  <p className="text-3xl font-bold text-gray-900">24 Transactions</p>
                  <p className="text-gray-400 text-xs mt-2">This month</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common banking tasks at your fingertips</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <button 
                    onClick={() => setShowTopup(true)}
                    className="flex flex-col items-center p-6 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors group"
                  >
                    <div className="w-14 h-14 bg-[#0C4BB9] rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <Plus className="w-7 h-7 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">Top Up</span>
                    <span className="text-xs text-gray-500 mt-1">Add Funds</span>
                  </button>
                  
                  <button 
                    onClick={() => setShowMobileDeposit(true)}
                    className="flex flex-col items-center p-6 bg-green-50 rounded-xl hover:bg-green-100 transition-colors group"
                  >
                    <div className="w-14 h-14 bg-green-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <Smartphone className="w-7 h-7 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">Mobile Deposit</span>
                    <span className="text-xs text-gray-500 mt-1">Deposit Check</span>
                  </button>
                  
                  <button 
                    onClick={() => setShowCheckDeposit(true)}
                    className="flex flex-col items-center p-6 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors group"
                  >
                    <div className="w-14 h-14 bg-purple-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <FileText className="w-7 h-7 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">Check Deposit</span>
                    <span className="text-xs text-gray-500 mt-1">Scan & Deposit</span>
                  </button>
                  
                  <button 
                    onClick={() => setShowGetCard(true)}
                    className="flex flex-col items-center p-6 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors group"
                  >
                    <div className="w-14 h-14 bg-orange-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                      <CreditCard className="w-7 h-7 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">Get Card</span>
                    <span className="text-xs text-gray-500 mt-1">Debit/Credit</span>
                  </button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Recent Transactions</CardTitle>
                  <CardDescription>Your latest account activity</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  View All
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {MOCK_TRANSACTIONS.slice(0, 5).map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          transaction.type === 'credit' ? 'bg-green-100' : 'bg-red-100'
                        }`}>
                          {transaction.type === 'credit' ? (
                            <Plus className={`w-5 h-5 ${transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}`} />
                          ) : (
                            <Minus className="w-5 h-5 text-red-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{transaction.description}</p>
                          <p className="text-sm text-gray-500">{transaction.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                          {transaction.type === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                        </p>
                        <Badge variant="outline" className="text-xs">
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Accounts Tab */}
          <TabsContent value="accounts" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Your Accounts</CardTitle>
                <CardDescription>Manage all your Chase accounts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-6 bg-gradient-to-r from-[#0C4BB9] to-[#003087] rounded-xl text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100 text-sm">Chase Private Client</p>
                      <p className="text-2xl font-bold mt-1">Checking Account</p>
                      <p className="text-blue-200 text-sm mt-1">{user.accountNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold">{formatCurrency(user.balance)}</p>
                      <p className="text-blue-200 text-sm">Current Balance</p>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-6">
                    <Button className="bg-white text-[#0C4BB9] hover:bg-blue-50">
                      <Send className="w-4 h-4 mr-2" />
                      Transfer
                    </Button>
                    <Button variant="outline" className="border-white text-white hover:bg-white/20">
                      <Download className="w-4 h-4 mr-2" />
                      Statements
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="border border-gray-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-500">Savings Account</p>
                          <p className="text-xl font-bold text-gray-900">{formatCurrency(250000)}</p>
                          <p className="text-xs text-gray-400">****7821</p>
                        </div>
                        <div className="p-3 bg-blue-100 rounded-lg">
                          <TrendingUp className="w-5 h-5 text-blue-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border border-gray-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-500">Investment Account</p>
                          <p className="text-xl font-bold text-gray-900">{formatCurrency(450000)}</p>
                          <p className="text-xs text-gray-400">****3456</p>
                        </div>
                        <div className="p-3 bg-green-100 rounded-lg">
                          <Activity className="w-5 h-5 text-green-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transfers Tab */}
          <TabsContent value="transfers" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Transfer Money</CardTitle>
                <CardDescription>Send money to other US banks. Requires PIN and agent approval.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">From Account</label>
                    <select className="w-full h-12 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0C4BB9] focus:border-transparent">
                      <option>Chase Private Client - {formatCurrency(user.balance)}</option>
                      <option>Savings Account - {formatCurrency(250000)}</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">To Bank *</label>
                    <select 
                      value={transferBank}
                      onChange={(e) => setTransferBank(e.target.value)}
                      className="w-full h-12 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0C4BB9] focus:border-transparent"
                      required
                    >
                      <option value="">Select a bank</option>
                      {USA_BANKS.map((bank) => (
                        <option key={bank} value={bank}>{bank}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Account Holder Name *</label>
                    <Input 
                      placeholder="Enter recipient's full name"
                      value={transferHolder}
                      onChange={(e) => setTransferHolder(e.target.value)}
                      className="h-12" 
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">To Account Number *</label>
                    <Input 
                      placeholder="Enter account number"
                      value={transferAccount}
                      onChange={(e) => setTransferAccount(e.target.value)}
                      className="h-12" 
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Amount *</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-lg">$</span>
                    <Input 
                      type="number" 
                      placeholder="0.00" 
                      value={transferAmount}
                      onChange={(e) => setTransferAmount(e.target.value)}
                      className="h-12 pl-10 text-lg" 
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Memo (Optional)</label>
                  <Input 
                    placeholder="Add a note for this transfer"
                    value={transferMemo}
                    onChange={(e) => setTransferMemo(e.target.value)}
                    className="h-12" 
                  />
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-800">Security Notice</p>
                      <p className="text-sm text-amber-700">This transfer requires your 4-digit PIN and approval from a customer care agent before completion.</p>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleTransferSubmit}
                  disabled={!transferBank || !transferAccount || !transferAmount || !transferHolder}
                  className="w-full h-12 bg-[#0C4BB9] hover:bg-[#003087]"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Continue to PIN Verification
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bank Search Tab */}
          <TabsContent value="search" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Bank Account Search</CardTitle>
                <CardDescription>Search for accounts across USA banks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      placeholder="Search by bank name, account holder, or account number..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="h-14 pl-12 text-lg"
                      onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    />
                  </div>
                  <Button 
                    onClick={handleSearch}
                    className="h-14 px-8 bg-[#0C4BB9] hover:bg-[#003087]"
                    disabled={isSearching}
                  >
                    {isSearching ? (
                      <RefreshCw className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <Search className="w-5 h-5 mr-2" />
                        Search
                      </>
                    )}
                  </Button>
                </div>

                {/* Supported Banks */}
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="text-sm font-medium text-blue-900 mb-2">Supported Banks:</p>
                  <div className="flex flex-wrap gap-2">
                    {USA_BANKS.slice(0, 10).map((bank) => (
                      <Badge key={bank} variant="secondary" className="bg-white text-blue-700">
                        <Landmark className="w-3 h-3 mr-1" />
                        {bank}
                      </Badge>
                    ))}
                    <Badge variant="secondary" className="bg-white text-blue-700">+10 more</Badge>
                  </div>
                </div>

                {/* Search Results */}
                {searchResults.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900">Search Results ({searchResults.length} found)</h3>
                    <div className="grid grid-cols-1 gap-4">
                      {searchResults.map((account) => (
                        <Card key={account.id} className="border border-gray-200 hover:border-[#0C4BB9] transition-colors cursor-pointer"
                          onClick={() => setSelectedAccount(account)}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-[#0C4BB9] rounded-lg flex items-center justify-center">
                                  <Building2 className="w-6 h-6 text-white" />
                                </div>
                                <div>
                                  <p className="font-semibold text-gray-900">{account.bankName}</p>
                                  <p className="text-sm text-gray-500">{account.accountHolder}</p>
                                  <p className="text-xs text-gray-400">{account.accountNumber} • {account.accountType}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-xl font-bold text-gray-900">{formatCurrency(account.balance)}</p>
                                <p className="text-xs text-gray-400">Routing: {account.routingNumber}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {searchResults.length === 0 && searchQuery && !isSearching && (
                  <div className="text-center py-12">
                    <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No accounts found matching your search.</p>
                    <p className="text-sm text-gray-400 mt-1">Try searching with different keywords</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Account Detail Dialog */}
      <Dialog open={!!selectedAccount} onOpenChange={() => setSelectedAccount(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="w-6 h-6 text-[#0C4BB9]" />
              Account Details
            </DialogTitle>
          </DialogHeader>
          {selectedAccount && (
            <div className="space-y-4">
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-sm text-blue-600 font-medium">{selectedAccount.bankName}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{formatCurrency(selectedAccount.balance)}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Account Holder</p>
                  <p className="font-medium">{selectedAccount.accountHolder}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Account Type</p>
                  <p className="font-medium">{selectedAccount.accountType}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Account Number</p>
                  <p className="font-medium">{selectedAccount.accountNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Routing Number</p>
                  <p className="font-medium">{selectedAccount.routingNumber}</p>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <Button className="flex-1 bg-[#0C4BB9] hover:bg-[#003087]">
                  <Send className="w-4 h-4 mr-2" />
                  Transfer to This Account
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-6 h-6 text-[#0C4BB9]" />
              Account Settings
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-[#0C4BB9] rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <div>
                <p className="text-xl font-bold text-gray-900">{user.name}</p>
                <p className="text-sm text-gray-500">Chase Private Client</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <Calendar className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Date of Birth</p>
                  <p className="font-medium text-gray-900">{user.dob}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <MapPin className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Location</p>
                  <p className="font-medium text-gray-900">{user.location}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <Phone className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Phone Number</p>
                  <p className="font-medium text-gray-900">{user.phone}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <CreditCard className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Account Number</p>
                  <p className="font-medium text-gray-900">{user.accountNumber}</p>
                </div>
              </div>
            </div>
            
            {/* Security Settings */}
            <div className="border-t border-gray-200 pt-4">
              <p className="text-sm font-medium text-gray-700 mb-3">Security Settings</p>
              <div className="space-y-2">
                <button 
                  onClick={() => { setShowSettings(false); setShowChangePassword(true); }}
                  className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Lock className="w-5 h-5 text-gray-400" />
                    <span className="font-medium text-gray-900">Change Password</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
                <button 
                  onClick={() => { setShowSettings(false); setShowChangeEmail(true); }}
                  className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="font-medium text-gray-900">Change Email</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
              </div>
            </div>
            
            <Button onClick={() => setShowSettings(false)} className="w-full">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Change Password Dialog */}
      <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-6 h-6 text-[#0C4BB9]" />
              Change Password
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Current Password</label>
              <Input
                type="password"
                placeholder="Enter current password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">New Password</label>
              <Input
                type="password"
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Confirm New Password</label>
              <Input
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-12"
              />
            </div>
            <Button 
              onClick={() => {
                if (newPassword !== confirmPassword) {
                  alert('Passwords do not match!');
                  return;
                }
                if (newPassword.length < 6) {
                  alert('Password must be at least 6 characters!');
                  return;
                }
                alert('Password changed successfully!');
                setCurrentPassword('');
                setNewPassword('');
                setConfirmPassword('');
                setShowChangePassword(false);
              }}
              className="w-full bg-[#0C4BB9] hover:bg-[#003087]"
            >
              Update Password
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Change Email Dialog */}
      <Dialog open={showChangeEmail} onOpenChange={setShowChangeEmail}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-6 h-6 text-[#0C4BB9]" />
              Change Email Address
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-sm text-gray-500">Current Email</p>
              <p className="font-medium text-gray-900">{user.email}</p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">New Email Address</label>
              <Input
                type="email"
                placeholder="Enter new email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Password</label>
              <Input
                type="password"
                placeholder="Enter password to confirm"
                value={emailPassword}
                onChange={(e) => setEmailPassword(e.target.value)}
                className="h-12"
              />
            </div>
            <Button 
              onClick={() => {
                if (!newEmail.includes('@')) {
                  alert('Please enter a valid email address!');
                  return;
                }
                alert('Email changed successfully!');
                globalUserState.email = newEmail;
                setNewEmail('');
                setEmailPassword('');
                setShowChangeEmail(false);
              }}
              className="w-full bg-[#0C4BB9] hover:bg-[#003087]"
            >
              Update Email
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* PIN Dialog */}
      <Dialog open={showPinDialog} onOpenChange={setShowPinDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-6 h-6 text-[#0C4BB9]" />
              Enter PIN
            </DialogTitle>
            <DialogDescription>
              Please enter your 4-digit PIN to authorize this transfer.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div className="flex justify-center gap-3">
              {[0, 1, 2, 3].map((i) => (
                <Input
                  key={i}
                  type="password"
                  maxLength={1}
                  value={transferPin[i] || ''}
                  onChange={(e) => {
                    const newPin = transferPin.split('');
                    newPin[i] = e.target.value;
                    setTransferPin(newPin.join(''));
                    if (e.target.value && i < 3) {
                      const nextInput = e.target.parentElement?.nextElementSibling?.querySelector('input');
                      nextInput?.focus();
                    }
                  }}
                  className="w-14 h-14 text-center text-2xl font-bold"
                />
              ))}
            </div>
            <Button 
              onClick={handlePinSubmit}
              disabled={transferPin.length !== 4}
              className="w-full bg-[#0C4BB9] hover:bg-[#003087]"
            >
              Verify PIN
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pending Approval Dialog */}
      <Dialog open={showPendingDialog} onOpenChange={setShowPendingDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <Clock className="w-6 h-6" />
              Transfer Pending Approval
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <p className="text-amber-800">
                Your transfer request has been submitted and is pending approval from a customer care agent.
              </p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-gray-500">Transfer Details:</p>
              <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                <p><span className="text-gray-500">To Bank:</span> <span className="font-medium">{pendingTransfers[pendingTransfers.length - 1]?.toBank}</span></p>
                <p><span className="text-gray-500">Account:</span> <span className="font-medium">{pendingTransfers[pendingTransfers.length - 1]?.toAccount}</span></p>
                <p><span className="text-gray-500">Amount:</span> <span className="font-medium text-[#0C4BB9]">{formatCurrency(pendingTransfers[pendingTransfers.length - 1]?.amount || 0)}</span></p>
              </div>
            </div>
            <p className="text-sm text-gray-500">
              You will be notified once the agent reviews and approves your transfer request.
            </p>
            <Button onClick={() => setShowPendingDialog(false)} className="w-full">
              OK
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Contact Agent Dialog */}
      <Dialog open={showContactAgentDialog} onOpenChange={setShowContactAgentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <Shield className="w-6 h-6" />
              Security Verification Required
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-amber-600 mt-0.5" />
                <div>
                  <p className="font-medium text-amber-800">Transfer Authorization Required</p>
                  <p className="text-sm text-amber-700 mt-1">
                    For your security, this transfer requires additional verification by a customer care agent.
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm font-medium text-blue-900 mb-2">Please contact customer care:</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-blue-800">
                  <Phone className="w-4 h-4" />
                  <span className="font-medium">{CUSTOMER_CARE.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-blue-800">
                  <Mail className="w-4 h-4" />
                  <span>{CUSTOMER_CARE.email}</span>
                </div>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              <p>Reference your account: <span className="font-medium text-gray-700">{user.accountNumber}</span></p>
              <p className="mt-1">Our agents are available 24/7 to assist you with this transfer.</p>
            </div>
            <Button onClick={() => setShowContactAgentDialog(false)} className="w-full">
              I Understand
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Top Up Dialog */}
      <Dialog open={showTopup} onOpenChange={setShowTopup}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-6 h-6 text-green-600" />
              Top Up Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600">Add funds to your Chase account instantly.</p>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-lg">$</span>
                <Input type="number" placeholder="0.00" className="h-12 pl-10 text-lg" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">From</label>
              <select className="w-full h-12 px-4 border border-gray-300 rounded-lg">
                <option>External Bank Account</option>
                <option>Debit Card</option>
                <option>Cash Deposit</option>
              </select>
            </div>
            <Button onClick={() => setShowTopup(false)} className="w-full bg-green-600 hover:bg-green-700">
              Continue
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Mobile Deposit Dialog */}
      <Dialog open={showMobileDeposit} onOpenChange={setShowMobileDeposit}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="w-6 h-6 text-green-600" />
              Mobile Deposit
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <QrCode className="w-12 h-12 text-green-600" />
              </div>
              <p className="text-green-800 font-medium">Scan Check to Deposit</p>
              <p className="text-sm text-green-600 mt-2">Position your check within the frame</p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Check Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-lg">$</span>
                <Input type="number" placeholder="0.00" className="h-12 pl-10 text-lg" />
              </div>
            </div>
            <Button onClick={() => setShowMobileDeposit(false)} className="w-full bg-green-600 hover:bg-green-700">
              Capture Check
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Check Deposit Dialog */}
      <Dialog open={showCheckDeposit} onOpenChange={setShowCheckDeposit}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-6 h-6 text-purple-600" />
              Check Deposit
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600">Deposit a check by entering the details below.</p>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Check Number</label>
              <Input placeholder="Enter check number" className="h-12" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-lg">$</span>
                <Input type="number" placeholder="0.00" className="h-12 pl-10 text-lg" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Payee Name</label>
              <Input placeholder="Enter payee name" className="h-12" />
            </div>
            <Button onClick={() => setShowCheckDeposit(false)} className="w-full bg-purple-600 hover:bg-purple-700">
              Submit Deposit
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Get Card Dialog */}
      <Dialog open={showGetCard} onOpenChange={setShowGetCard}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="w-6 h-6 text-orange-600" />
              Request New Card
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600">Choose the type of card you'd like to request.</p>
            <div className="grid grid-cols-2 gap-4">
              <button className="p-6 border-2 border-gray-200 rounded-xl hover:border-[#0C4BB9] transition-colors text-center">
                <div className="w-16 h-10 bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg mx-auto mb-3" />
                <p className="font-medium text-gray-900">Debit Card</p>
                <p className="text-xs text-gray-500 mt-1">Instant Issue</p>
              </button>
              <button className="p-6 border-2 border-gray-200 rounded-xl hover:border-[#0C4BB9] transition-colors text-center">
                <div className="w-16 h-10 bg-gradient-to-r from-purple-600 to-purple-800 rounded-lg mx-auto mb-3" />
                <p className="font-medium text-gray-900">Credit Card</p>
                <p className="text-xs text-gray-500 mt-1">Apply Now</p>
              </button>
            </div>
            <Button onClick={() => setShowGetCard(false)} variant="outline" className="w-full">
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Admin Panel Component
const AdminPanel = ({ onLogout, updateUserLockStatus }: { onLogout: () => void; updateUserLockStatus: (userId: string, isLocked: boolean) => void }) => {
  const [users, setUsers] = useState<User[]>([globalUserState]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showLockDialog, setShowLockDialog] = useState(false);
  const [lockReason, setLockReason] = useState('');
  const [adminTab, setAdminTab] = useState('accounts');
  const [transfers, setTransfers] = useState<PendingTransfer[]>(pendingTransfers);
  const [selectedTransfer, setSelectedTransfer] = useState<PendingTransfer | null>(null);
  const [showTransferDialog, setShowTransferDialog] = useState(false);
  
  // Edit account state
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDob, setEditDob] = useState('');
  const [editBalance, setEditBalance] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editPhone, setEditPhone] = useState('');

  // Refresh transfers periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setTransfers([...pendingTransfers]);
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  
  const handleEditAccount = (user: User) => {
    setSelectedUser(user);
    setEditName(user.name);
    setEditDob(user.dob);
    setEditBalance(user.balance.toString());
    setEditLocation(user.location);
    setEditPhone(user.phone);
    setShowEditDialog(true);
  };
  
  const saveAccountChanges = () => {
    if (selectedUser) {
      const updatedUser = { 
        ...selectedUser, 
        name: editName,
        dob: editDob,
        balance: parseFloat(editBalance) || 0,
        location: editLocation,
        phone: editPhone
      };
      setUsers(users.map(u => u.id === selectedUser.id ? updatedUser : u));
      globalUserState = updatedUser;
      setShowEditDialog(false);
      setSelectedUser(null);
    }
  };

  const handleLockToggle = (user: User) => {
    if (user.isLocked) {
      // Unlock - update both local and global state
      const updatedUser = { ...user, isLocked: false };
      setUsers(users.map(u => u.id === user.id ? updatedUser : u));
      updateUserLockStatus(user.id, false);
      globalUserState = updatedUser;
      setSelectedUser(null);
    } else {
      // Show lock dialog
      setSelectedUser(user);
      setShowLockDialog(true);
    }
  };

  const confirmLock = () => {
    if (selectedUser) {
      // Lock - update both local and global state
      const updatedUser = { ...selectedUser, isLocked: true };
      setUsers(users.map(u => u.id === selectedUser.id ? updatedUser : u));
      updateUserLockStatus(selectedUser.id, true);
      globalUserState = updatedUser;
      setShowLockDialog(false);
      setLockReason('');
      setSelectedUser(null);
    }
  };

  const handleApproveTransfer = (transfer: PendingTransfer) => {
    transfer.status = 'approved';
    // Deduct from user balance
    globalUserState.balance -= transfer.amount;
    setTransfers([...transfers]);
    setShowTransferDialog(false);
    setSelectedTransfer(null);
  };

  const handleRejectTransfer = (transfer: PendingTransfer) => {
    transfer.status = 'rejected';
    setTransfers([...transfers]);
    setShowTransferDialog(false);
    setSelectedTransfer(null);
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.accountNumber.includes(searchQuery)
  );

  const pendingTransfersList = transfers.filter(t => t.status === 'pending');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8" />
              <div>
                <h1 className="text-xl font-bold">Customer Care Admin</h1>
                <p className="text-xs text-gray-400">Account Management System</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium">Admin User</p>
                <p className="text-xs text-gray-400">Level 3 Access</p>
              </div>
              <Button variant="ghost" onClick={onLogout} className="text-white hover:bg-gray-800">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Accounts</p>
                  <p className="text-3xl font-bold">{users.length}</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Accounts</p>
                  <p className="text-3xl font-bold text-green-600">{users.filter(u => !u.isLocked).length}</p>
                </div>
                <div className="p-3 bg-green-100 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Locked Accounts</p>
                  <p className="text-3xl font-bold text-red-600">{users.filter(u => u.isLocked).length}</p>
                </div>
                <div className="p-3 bg-red-100 rounded-lg">
                  <Lock className="w-6 h-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Assets</p>
                  <p className="text-3xl font-bold">{formatCurrency(users.reduce((sum, u) => sum + u.balance, 0))}</p>
                </div>
                <div className="p-3 bg-purple-100 rounded-lg">
                  <DollarSign className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={adminTab} onValueChange={setAdminTab} className="space-y-6">
          <TabsList className="bg-white border border-gray-200 p-1">
            <TabsTrigger value="accounts" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              Accounts
            </TabsTrigger>
            <TabsTrigger value="transfers" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white">
              <Send className="w-4 h-4 mr-2" />
              Pending Transfers
              {pendingTransfersList.length > 0 && (
                <Badge className="ml-2 bg-red-500 text-white">{pendingTransfersList.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-6">
            {/* Search */}
            <Card className="border-0 shadow mb-6">
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search accounts by name, email, or account number..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="h-12 pl-12"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Accounts Table */}
            <Card className="border-0 shadow">
              <CardHeader>
                <CardTitle>Account Management</CardTitle>
                <CardDescription>View and manage customer accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-medium text-gray-500">Account Holder</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-500">Email</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-500">Account</th>
                        <th className="text-right py-3 px-4 font-medium text-gray-500">Balance</th>
                        <th className="text-center py-3 px-4 font-medium text-gray-500">Status</th>
                        <th className="text-right py-3 px-4 font-medium text-gray-500">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-[#0C4BB9] rounded-full flex items-center justify-center">
                                <User className="w-5 h-5 text-white" />
                              </div>
                              <span className="font-medium">{user.name}</span>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-gray-600">{user.email}</td>
                          <td className="py-4 px-4 text-gray-600">{user.accountNumber}</td>
                          <td className="py-4 px-4 text-right font-medium">{formatCurrency(user.balance)}</td>
                          <td className="py-4 px-4 text-center">
                            {user.isLocked ? (
                              <Badge className="bg-red-100 text-red-700">
                                <Lock className="w-3 h-3 mr-1" />
                                Locked
                              </Badge>
                            ) : (
                              <Badge className="bg-green-100 text-green-700">
                                <Unlock className="w-3 h-3 mr-1" />
                                Active
                              </Badge>
                            )}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditAccount(user)}
                                className="text-[#0C4BB9] border-[#0C4BB9] hover:bg-blue-50"
                              >
                                <Settings className="w-4 h-4 mr-1" />
                                Edit
                              </Button>
                              <Button
                                variant={user.isLocked ? "outline" : "destructive"}
                                size="sm"
                                onClick={() => handleLockToggle(user)}
                              >
                                {user.isLocked ? (
                                  <>
                                    <Unlock className="w-4 h-4 mr-1" />
                                    Unlock
                                  </>
                                ) : (
                                  <>
                                    <Lock className="w-4 h-4 mr-1" />
                                    Lock
                                  </>
                                )}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transfers" className="space-y-6">
            <Card className="border-0 shadow">
              <CardHeader>
                <CardTitle>Pending Transfer Approvals</CardTitle>
                <CardDescription>Review and approve customer transfer requests</CardDescription>
              </CardHeader>
              <CardContent>
                {pendingTransfersList.length === 0 ? (
                  <div className="text-center py-12">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <p className="text-gray-500">No pending transfers</p>
                    <p className="text-sm text-gray-400 mt-1">All transfer requests have been processed</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingTransfersList.map((transfer) => (
                      <Card key={transfer.id} className="border border-gray-200">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                                <Clock className="w-6 h-6 text-amber-600" />
                              </div>
                              <div>
                                <p className="font-semibold text-gray-900">Transfer to {transfer.toBank}</p>
                                <p className="text-sm text-gray-500">Account: {transfer.toAccount}</p>
                                <p className="text-sm text-gray-500">Holder: {transfer.accountHolder}</p>
                                {transfer.memo && <p className="text-xs text-gray-400 mt-1">Memo: {transfer.memo}</p>}
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-2xl font-bold text-[#0C4BB9]">{formatCurrency(transfer.amount)}</p>
                              <p className="text-xs text-gray-400">{new Date(transfer.requestedAt).toLocaleString()}</p>
                              <div className="flex gap-2 mt-3">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => { setSelectedTransfer(transfer); setShowTransferDialog(true); }}
                                >
                                  Review
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Lock Dialog */}
      <Dialog open={showLockDialog} onOpenChange={setShowLockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Lock className="w-6 h-6" />
              Lock Account
            </DialogTitle>
            <DialogDescription>
              You are about to lock the account for {selectedUser?.name}. This will prevent them from accessing online banking.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Reason for locking (required)</label>
              <textarea
                value={lockReason}
                onChange={(e) => setLockReason(e.target.value)}
                placeholder="Enter the reason for locking this account..."
                className="w-full h-24 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setShowLockDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={confirmLock}
                disabled={!lockReason.trim()}
                className="bg-red-600 hover:bg-red-700"
              >
                <Lock className="w-4 h-4 mr-2" />
                Confirm Lock
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Account Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-6 h-6 text-[#0C4BB9]" />
              Edit Account Details
            </DialogTitle>
            <DialogDescription>
              Modify customer account information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Account Holder Name</label>
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Enter full name"
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Date of Birth</label>
              <Input
                value={editDob}
                onChange={(e) => setEditDob(e.target.value)}
                placeholder="e.g., 22 Aug 1961"
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Account Balance ($)</label>
              <Input
                type="number"
                value={editBalance}
                onChange={(e) => setEditBalance(e.target.value)}
                placeholder="Enter balance"
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Location</label>
              <Input
                value={editLocation}
                onChange={(e) => setEditLocation(e.target.value)}
                placeholder="e.g., Savannah, Georgia"
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Phone Number</label>
              <Input
                value={editPhone}
                onChange={(e) => setEditPhone(e.target.value)}
                placeholder="e.g., +1 (912) 555-0147"
                className="h-12"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={saveAccountChanges}
                className="flex-1 bg-[#0C4BB9] hover:bg-[#003087]"
              >
                <Check className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Transfer Approval Dialog */}
      <Dialog open={showTransferDialog} onOpenChange={setShowTransferDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="w-6 h-6 text-[#0C4BB9]" />
              Review Transfer Request
            </DialogTitle>
          </DialogHeader>
          {selectedTransfer && (
            <div className="space-y-4">
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-[#0C4BB9]">{formatCurrency(selectedTransfer.amount)}</p>
                <p className="text-sm text-blue-600 mt-1">Transfer Amount</p>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-500">To Bank:</span>
                  <span className="font-medium">{selectedTransfer.toBank}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Account Number:</span>
                  <span className="font-medium">{selectedTransfer.toAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Account Holder:</span>
                  <span className="font-medium">{selectedTransfer.accountHolder}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">From Account:</span>
                  <span className="font-medium">{selectedTransfer.fromAccount}</span>
                </div>
                {selectedTransfer.memo && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Memo:</span>
                    <span className="font-medium">{selectedTransfer.memo}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-500">Requested:</span>
                  <span className="font-medium">{new Date(selectedTransfer.requestedAt).toLocaleString()}</span>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowTransferDialog(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={() => handleRejectTransfer(selectedTransfer)}
                  variant="destructive"
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-2" />
                  Reject
                </Button>
                <Button 
                  onClick={() => handleApproveTransfer(selectedTransfer)}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Approve
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Main App Component
function App() {
  const { isAuthenticated, isAdmin, login, logout, adminLogin, updateUserLockStatus } = useAuth();

  const handleAdminLogin = (username: string, password: string): boolean => {
    return adminLogin(username, password);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? 
              (isAdmin ? <Navigate to="/admin" /> : <Navigate to="/dashboard" />) :
              <LoginPage onLogin={login} />
          } 
        />
        <Route 
          path="/admin-login" 
          element={
            isAuthenticated ? <Navigate to="/admin" /> : <AdminLoginPage onAdminLogin={handleAdminLogin} />
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            isAuthenticated && !isAdmin ? 
              <Dashboard onLogout={handleLogout} /> : 
              <Navigate to="/" />
          } 
        />
        <Route 
          path="/admin" 
          element={
            isAuthenticated && isAdmin ? 
              <AdminPanel onLogout={handleLogout} updateUserLockStatus={updateUserLockStatus} /> : 
              <Navigate to="/admin-login" />
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
